﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BingMapsWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //VARIABLES INSTANTIATED

        Boolean BrowserVisibility = true;
        Boolean MapVisibility = false;

        Boolean FirstTimeUser = true;




        //VARIABLE SETUP

        //setting ARTICLES linked list to 

        //setting ARTICLES pane to the ARTICLES linked list

        //setting the TREE pane to the directory



        //


        //if the user hasn't used the program before, a little setup....
        //if (FirstTimeUser == true)
        //{
            //first time user stuff here    
        //}



        //CONSTRUCTORS
        public MainWindow()
        {
            InitializeComponent();
        }









        //EVENTS






        //SWITCH BETWEEN READER VIEW AND MAP VIEW
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //RUNNING FINE HERE
            if (BrowserVisibility == true && MapVisibility == false)
            {
                myWebBrowser.Visibility = Visibility.Hidden;
                myMap.Visibility = Visibility.Visible;
                BrowserVisibility = false;
                MapVisibility = true;

            }
            else if (BrowserVisibility == false && MapVisibility == true)
            {
                myWebBrowser.Visibility = Visibility.Visible;
                myMap.Visibility = Visibility.Hidden;
                BrowserVisibility = true;
                MapVisibility = false;

            }
            //CHECKING FOR ERROR HERE
            else if (MapVisibility == true && BrowserVisibility == true)
            {
                Console.WriteLine("ERROR : BOTH MAP AND BROWSER ARE VISIBLE");
            }
            else if (MapVisibility == false && BrowserVisibility == false)
            {
                Console.WriteLine("ERROR : BOTH MAP AND BROWSER ARE INVISIBLE");
            }
            //ELSE....
            else
            {
                Console.WriteLine("ERROR : I DON'T KNOW WHAT THE HELL'S GOING ON");
            }
        }



        //CYCLE THROUGH THE ELEMENTS OF THE ARTICLE PANE





        //DRAG AND DROP ELEMENTS OF TREE VIEW




    }
}
